package com.toukei.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.toukei.controller.CatController;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration("web.xml")
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/dispatcher-servlet.xml", "file:src/main/webapp/WEB-INF/jdbc.xml",
		"file:src/main/webapp/WEB-INF/root-context.xml", "file:src/main/webapp/WEB-INF/config-security.xml" })
public class TestCatDAO {
	@Autowired
	private CatController catController;
	
	@Test
	public void test() {
		assertEquals("index", catController.index());
	}

}
