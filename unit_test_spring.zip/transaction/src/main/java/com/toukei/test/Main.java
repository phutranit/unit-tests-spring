package com.toukei.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.toukei.dao.CatDAO;
import com.toukei.model.Cat;

public class Main {
	public static void main(String[] args) {
		ApplicationContext ctx = new FileSystemXmlApplicationContext("spring.xml");
        CatDAO catDAO = (CatDAO) ctx.getBean("catDAO");
        catDAO.update(new Cat(0, "demo1"));
	}
}
