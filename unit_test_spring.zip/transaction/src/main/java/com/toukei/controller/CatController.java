package com.toukei.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.toukei.dao.CatDAO;
import com.toukei.model.Cat;

@Controller
public class CatController {
	@Autowired
	private CatDAO catDAO;
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String index() {
		catDAO.update(new Cat(11, "DDDDDDDDDD"));
		return "index";
	}
}
