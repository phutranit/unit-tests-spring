package com.toukei.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BcryptController {
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@RequestMapping("create-password")
	@ResponseBody
	public String createPassword() {
		System.out.println(passwordEncoder.encode("123456"));
		return null;
	}
}
