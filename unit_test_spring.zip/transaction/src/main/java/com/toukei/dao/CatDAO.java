package com.toukei.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.toukei.model.Cat;

@Repository
public class CatDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional(rollbackFor = Exception.class)
	public void update(Cat cat) {
		String sql1 = "INSERT INTO categories(CID,CNAME) VALUES(?,?)";
		String sql2 = "INSERT INTO categories(CID,CNAME) VALUES(?,?)";
		jdbcTemplate.update(sql1, new Object[] {81, cat.getCname() });
		jdbcTemplate.update(sql2, new Object[] {91,cat.getCname() });
	}	
	
	public List<Cat> getItems() {
		String sql = "SELECT * FROM categories";
		return  jdbcTemplate.query(sql, new BeanPropertyRowMapper<Cat>(Cat.class));
	}

}
	